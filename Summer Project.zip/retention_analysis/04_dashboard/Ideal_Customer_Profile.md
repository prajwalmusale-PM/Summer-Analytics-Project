# Ideal Customer Profile (ICP)
## Decoding Customer Value — A SQL-Driven Retention Strategy

---

### ICP Definition
Derived from the **top-decile Value Score** (n=390 customers, 10% of the base). These customers represent the highest composite value after penalising promo dependency, rewarding engagement, satisfaction, and lifetime spend.

---

### The ICP Card

| Dimension | ICP Value | Rationale |
|-----------|-----------|-----------|
| **Age band** | 35-54 (avg: 44.2) | Peak spending years; highest LTV concentration |
| **Gender** | Male (subject to data-quirk caveat*) | Male represents 68% of dataset; 89% of discounted customers are Male |
| **Top category** | Clothing | Most common among top-decile; entry-point for cross-sell to Outerwear |
| **Top items** | Jewelry, Dress, Shoes | Highest frequency in top-decile purchase history |
| **Geography** | Arizona, Alaska, Pennsylvania, Wyoming, Illinois | Top 5 over-indexed states by customer concentration in top-decile |
| **Avg LTV** | **$3,646** | 2.4x the overall average ($1,518) |
| **Purchase cadence** | Weekly | Strongest signal for annualised spend and engagement |
| **Subscription** | Yes (26.4% rate in ICP) | Subscribers show higher retention and order frequency |
| **Promo usage** | < 36% (target the non-promo subset for lookalikes) | Non-promo ICP customers have highest loyalty and satisfaction |
| **Avg satisfaction** | >= 4.16 | Quality signal independent of spend |
| **Payment method** | Credit Card | Highest LTV payment method ($1,544 avg); lowest friction |
| **Shipping preference** | Express | Correlates with higher engagement and purchase urgency |

---

### Critical Data Caveats

**Female-Discount Quirk:** All 1,248 Female customers in the dataset have `Discount_Applied = No`. This is either a data artefact or a programme rule. **Action:** Treat gender as a secondary ICP dimension; do NOT exclude Female customers from acquisition. Run an A/B test offering targeted discounts to Female lookalikes to validate true discount sensitivity.

**Subscription-Discount Overlap:** 100% of subscribers receive a discount (1,053/1,053), but only 26.4% of the ICP subscribes. **Action:** Untangle subscription perks from blanket discounts — offer exclusive access / early drops instead of price cuts.

---

### How to Use This ICP Today

**Meta Ads Audience Builder:**
- Age: 35-54
- Gender: All (test Male skew vs. balanced)
- Interests: Fashion, Premium Clothing, Online Shopping
- Location: Arizona, Pennsylvania, Alaska, Wyoming, Illinois (start) + other under-leveraged states
- Behaviour: Frequent online shoppers, Credit Card payers
- Lookalike: Upload the 390 top-decile Customer IDs as a seed audience

**Campaign Messaging:**
- Lead with quality and exclusivity, NOT discounts
- Highlight "new arrivals" and "limited drops" (ICP responds to urgency)
- Emphasise free express shipping over percentage-off
- Use subscription as a loyalty lever, not a discount gateway

**Expected Acquisition CAC Target:** Based on ICP LTV of $3,646 and 3:1 LTV:CAC ratio, target CAC <= $1,215 per ICP-acquired customer.

---

*ICP derived from Q9 SQL query: population statistics for top-decile Value_Score customers. All figures validated against full 3,900-customer dataset.*
