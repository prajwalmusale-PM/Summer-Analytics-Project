# DAX Measures — Founder Dashboard
## Power BI Measures Table (_Measures)

### Global Measures
```dax
Total Revenue = SUM ( customers[lifetime_spend] )

Customers = DISTINCTCOUNT ( customers[customer_id] )

Avg LTV = DIVIDE ( [Total Revenue], [Customers] )

Promo Revenue = CALCULATE ( [Total Revenue], customers[discount_applied] = "Yes" )

Promo Revenue % = DIVIDE ( [Promo Revenue], [Total Revenue] )

Avg Loyalty B = AVERAGE ( customers[loyalty_b] )

Avg Satisfaction = AVERAGE ( customers[review_rating] )

Genuine Loyal Count = CALCULATE ( [Customers], customers[segment] = "High-Value Loyal" )

National Avg LTV = CALCULATE ( [Avg LTV], ALL ( customers ) )

Opportunity Index = DIVIDE ( [Avg LTV], [National Avg LTV] )
```

### Panel 1 — Customer Pyramid
```dax
Revenue Share = DIVIDE ( [Total Revenue], CALCULATE ( [Total Revenue], ALL ( customers[value_tier] ) ) )
```

### Panel 2 — Promo Dependency Matrix
```dax
Median Loyalty B = MEDIANX ( ALL ( customers ), customers[loyalty_b] )
```
*Add constant lines at x=0.3 (Discount Dependency Score) and y=[Median Loyalty B]*

### Panel 4 — Category Funnel
```dax
Entry Customers = CALCULATE ( [Customers], customers[previous_purchases] <= 13 )

Mid Customers = CALCULATE ( [Customers], customers[previous_purchases] >= 14 && customers[previous_purchases] <= 37 )

Loyal Customers = CALCULATE ( [Customers], customers[previous_purchases] >= 38 )
```

### Cross-Filtering Configuration
- **Slicers:** Segment, Value_Tier, Discount_Applied, Season
- **Drill-through:** Click any tier in Panel 1 → customer-level detail page
- **Interactions:** All visuals cross-filter by default
- **Test:** Select Segment="High-Value Promo-Driven" → Promo Revenue % should jump to 100%

### Visual Formatting Notes
- **Palette:** Corporate navy (#1a3a5c) → teal (#2e6b8a) → sky (#5a9ebf) → light (#a8d4e6)
- **Alert color:** #c44e52 (for promo-dependent segments)
- **Typography:** Segoe UI, 11-15px range
- **Background:** White panels on #f5f7fa canvas
- **Tooltips:** Every visual must include segment, LTV, and promo status
