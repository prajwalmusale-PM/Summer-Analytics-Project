-- ============================================================
-- Q7 — Demographics Creating Most Value
-- Age band x Gender breakdown by LTV and loyalty
-- ============================================================
SELECT 
    age_band,
    gender,
    COUNT(*) AS customers,
    ROUND(AVG(lifetime_spend), 0) AS avg_ltv,
    ROUND(AVG(loyalty_b), 3) AS avg_loyalty
FROM customers
GROUP BY 1, 2
ORDER BY avg_ltv DESC;
