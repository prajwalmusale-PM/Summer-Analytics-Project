-- ============================================================
-- Q10 — Segments to Sunset Discounts FIRST
-- Rule: sunset where value_tier IN ('Top','High') 
-- AND discount_applied='Yes' AND avg_loyalty is already high
-- These customers buy regardless of promo
-- ============================================================
SELECT 
    value_tier,
    discount_applied,
    COUNT(*) AS customers,
    ROUND(AVG(lifetime_spend), 0) AS avg_ltv,
    ROUND(AVG(loyalty_b), 3) AS avg_loyalty
FROM customers
GROUP BY 1, 2
ORDER BY value_tier, discount_applied;
