-- ============================================================
-- Q6 — Under-Leveraged Geographies
-- States with few customers but above-average LTV
-- Target for growth via lookalike acquisition
-- ============================================================
WITH bench AS (SELECT AVG(lifetime_spend) AS nat FROM customers)
SELECT 
    location,
    COUNT(*) AS customers,
    ROUND(AVG(lifetime_spend), 0) AS avg_ltv,
    ROUND(SUM(lifetime_spend), 0) AS state_revenue,
    ROUND(AVG(lifetime_spend) / (SELECT nat FROM bench), 2) AS opportunity_index
FROM customers
GROUP BY location
HAVING COUNT(*) < (SELECT AVG(cnt) FROM (SELECT COUNT(*) cnt FROM customers GROUP BY location) t)
    AND AVG(lifetime_spend) > (SELECT nat FROM bench)
ORDER BY opportunity_index DESC;
