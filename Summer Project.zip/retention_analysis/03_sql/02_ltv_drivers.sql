-- ============================================================
-- Q2 — Behaviours that Predict High LTV
-- Correlates frequency, subscription, satisfaction with spend
-- ============================================================
SELECT
    frequency_of_purchases,
    subscription_status,
    satisfied_flag,
    COUNT(*) AS customers,
    ROUND(AVG(lifetime_spend), 0) AS avg_ltv,
    ROUND(AVG(annualised_spend), 0) AS avg_annualised
FROM customers
GROUP BY 1, 2, 3
ORDER BY avg_ltv DESC
LIMIT 10;
