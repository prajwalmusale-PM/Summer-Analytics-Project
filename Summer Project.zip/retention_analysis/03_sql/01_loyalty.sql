-- ============================================================
-- Q1 — Genuinely Loyal vs Discount-Driven
-- Objective: rank customers, split top loyalty-B quintile into
-- "Genuine" (no discount) vs "Promo-Loyal" (discount used)
-- ============================================================
WITH ranked AS (
    SELECT *,
        NTILE(5) OVER (ORDER BY loyalty_b DESC) AS loyalty_quintile
    FROM customers
)
SELECT
    CASE WHEN discount_applied = 'No' THEN 'Genuine Loyal'
         ELSE 'Promo Loyal' END AS segment,
    COUNT(*) AS customers,
    ROUND(AVG(lifetime_spend), 2) AS avg_ltv,
    ROUND(AVG(satisfaction_score), 3) AS avg_satisfaction,
    ROUND(SUM(lifetime_spend), 0) AS total_revenue
FROM ranked
WHERE loyalty_quintile = 1
GROUP BY 1
ORDER BY total_revenue DESC;
