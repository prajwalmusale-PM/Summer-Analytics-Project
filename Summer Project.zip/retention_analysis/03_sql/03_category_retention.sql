-- ============================================================
-- Q3 — Retention-Driver Categories
-- Categories over-represented among high-tenure customers
-- (previous_purchases >= p75 = 38)
-- ============================================================
WITH high AS (SELECT * FROM customers WHERE previous_purchases >= 38)
SELECT
    category,
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM high), 2) AS pct_in_high_tenure,
    ROUND(100.0 * (SELECT COUNT(*) FROM customers c2 WHERE c2.category = high.category) / 3900.0, 2) AS pct_in_all,
    ROUND(AVG(lifetime_spend), 0) AS avg_ltv
FROM high
GROUP BY category
ORDER BY pct_in_high_tenure - pct_in_all DESC;
