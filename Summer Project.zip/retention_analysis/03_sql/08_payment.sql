-- ============================================================
-- Q8 — Payment Methods x Value
-- Which payment methods correlate with higher LTV
-- and which have highest promo dependency
-- ============================================================
SELECT 
    payment_method,
    COUNT(*) AS customers,
    ROUND(AVG(lifetime_spend), 0) AS avg_ltv,
    ROUND(100.0 * AVG(CASE WHEN discount_applied = 'Yes' THEN 1 ELSE 0 END), 2) AS pct_promo
FROM customers
GROUP BY payment_method
ORDER BY avg_ltv DESC;
