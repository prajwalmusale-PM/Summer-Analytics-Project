-- ============================================================
-- Q9 — Ideal Customer Profile (Top-Decile Value Score)
-- Population statistics for the highest-value 10% of customers
-- ============================================================
WITH top AS (
    SELECT * FROM customers
    WHERE value_score >= (SELECT value_score FROM customers ORDER BY value_score DESC LIMIT 1 OFFSET 389)
)
SELECT
    ROUND(AVG(age), 1) AS avg_age,
    (SELECT gender FROM top GROUP BY gender ORDER BY COUNT(*) DESC LIMIT 1) AS dominant_gender,
    (SELECT category FROM top GROUP BY category ORDER BY COUNT(*) DESC LIMIT 1) AS top_category,
    (SELECT payment_method FROM top GROUP BY payment_method ORDER BY COUNT(*) DESC LIMIT 1) AS top_payment,
    (SELECT frequency_of_purchases FROM top GROUP BY frequency_of_purchases ORDER BY COUNT(*) DESC LIMIT 1) AS top_cadence,
    ROUND(AVG(lifetime_spend), 0) AS avg_ltv,
    ROUND(100.0 * AVG(CASE WHEN discount_applied = 'Yes' THEN 1 ELSE 0 END), 1) AS pct_promo,
    ROUND(AVG(review_rating), 2) AS avg_rating
FROM top;
