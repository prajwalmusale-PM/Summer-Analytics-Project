-- ============================================================
-- 11_segments.sql — Customer Segmentation Assignment
-- Six segments, defined by Value_Tier x Discount_Dependency
-- Priority order: 1→6 (mutually exclusive, exhaustive)
-- ============================================================
ALTER TABLE customers ADD COLUMN segment TEXT;

UPDATE customers SET segment = CASE
    WHEN value_tier = 'Top' AND discount_applied = 'No' THEN 'High-Value Loyal'
    WHEN value_tier IN ('Top', 'High') AND discount_applied = 'Yes' THEN 'High-Value Promo-Driven'
    WHEN value_tier = 'High' AND subscription_status = 'Yes' 
         AND previous_purchases BETWEEN 14 AND 37 THEN 'Emerging Loyal'
    WHEN frequency_of_purchases IN ('Quarterly', 'Annually', 'Every 3 Months')
         AND previous_purchases < 13 THEN 'At-Risk'
    WHEN value_tier = 'Mid' AND regional_opportunity_score >= 1.0 THEN 'Growth Opportunity'
    ELSE 'Low-Value' 
END;

-- Validation: all 3,900 customers assigned exactly one segment
SELECT segment, COUNT(*) AS customers, ROUND(AVG(lifetime_spend), 0) AS avg_ltv
FROM customers
GROUP BY segment
ORDER BY avg_ltv DESC;
