-- ============================================================
-- Q4 — Entry-Point Categories
-- Categories over-represented among low-tenure customers
-- (previous_purchases <= p25 = 13)
-- ============================================================
WITH low AS (SELECT * FROM customers WHERE previous_purchases <= 13)
SELECT 
    category,
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM low), 2) AS pct_in_low_tenure,
    ROUND(AVG(purchase_amount_usd), 0) AS avg_first_basket
FROM low
GROUP BY category
ORDER BY pct_in_low_tenure DESC;
