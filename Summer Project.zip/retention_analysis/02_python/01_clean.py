# ============================================================
# 01_clean.py — Data loading, inspection, cleaning, validation
# ============================================================
import pandas as pd
import numpy as np

RAW = "Dataset.csv"
OUT = "customers_clean.csv"

# 1) LOAD ------------------------------------------------------
df = pd.read_csv(RAW)
df.columns = (df.columns.str.strip()
              .str.replace(" ", "_")
              .str.replace("(", "", regex=False)
              .str.replace(")", "", regex=False))

# 2) INSPECT ---------------------------------------------------
print(df.shape)  # expect (3900, 18)
print(df.isna().sum())  # expect 37 nulls in Review_Rating only
print(df.duplicated().sum())  # expect 0

# 3) DROP THE REDUNDANT COLUMN --------------------------------
assert (df["Promo_Code_Used"] == df["Discount_Applied"]).all(), \
    "Promo and Discount diverge — re-check before dropping"
df = df.drop(columns=["Promo_Code_Used"])

# 4) MISSING VALUE TREATMENT (Review_Rating) ------------------
df["Review_Rating"] = df.groupby("Category")["Review_Rating"]\
    .transform(lambda s: s.fillna(s.median()))

# 5) BINARISE Yes/No ------------------------------------------
for col in ["Subscription_Status", "Discount_Applied"]:
    df[col + "_bin"] = (df[col] == "Yes").astype(int)

# 6) FREQUENCY -> ORDERS PER YEAR -----------------------------
FREQ_MAP = {
    "Weekly": 52, "Bi-Weekly": 26, "Fortnightly": 26,
    "Monthly": 12, "Every 3 Months": 4, "Quarterly": 4, "Annually": 1
}
df["Orders_Per_Year"] = df["Frequency_of_Purchases"].map(FREQ_MAP)
assert df["Orders_Per_Year"].notna().all(), "Unmapped frequency value present"

# 7) OUTLIER CHECK (IQR) --------------------------------------
for c in ["Purchase_Amount_USD", "Previous_Purchases"]:
    q1, q3 = df[c].quantile([.25, .75])
    iqr = q3 - q1
    lo, hi = q1 - 1.5*iqr, q3 + 1.5*iqr
    n_out = ((df[c] < lo) | (df[c] > hi)).sum()
    print(f"{c}: IQR outliers = {n_out}")

# 8) INVALID DATA ---------------------------------------------
assert df["Age"].between(13, 100).all()
assert df["Purchase_Amount_USD"].between(1, 1000).all()
assert df["Review_Rating"].between(0, 5).all()

# 9) AGE BANDING ----------------------------------------------
df["Age_Band"] = pd.cut(df["Age"],
    bins=[17, 24, 34, 44, 54, 70],
    labels=["18-24", "25-34", "35-44", "45-54", "55-70"])

# 10) SAVE -----------------------------------------------------
df.to_csv(OUT, index=False)
print("Saved", OUT, df.shape)
