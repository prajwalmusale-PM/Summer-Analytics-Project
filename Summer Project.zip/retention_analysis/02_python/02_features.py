# ============================================================
# 02_features.py — Feature Engineering
# ============================================================
import pandas as pd
import numpy as np

df = pd.read_csv("customers_clean.csv")

# ---------- A. VALUE FEATURES --------------------------------
df["Avg_Order_Value"] = df["Purchase_Amount_USD"]
df["Lifetime_Spend"] = df["Purchase_Amount_USD"] * df["Previous_Purchases"]
df["Annualised_Spend"] = df["Avg_Order_Value"] * df["Orders_Per_Year"]
df["Spend_Per_Order"] = df["Avg_Order_Value"]

# ---------- B. PROMO / DISCOUNT FEATURES ---------------------
df["Promo_Reliant_Flag"] = df["Discount_Applied_bin"]
df["Discount_Dependency_Score"] = (
    0.6 * df["Discount_Applied_bin"]
    + 0.4 * df["Subscription_Status_bin"]
)
df["Full_Price_Buyer_Flag"] = (df["Discount_Applied_bin"] == 0).astype(int)

# ---------- C. BEHAVIOUR / ENGAGEMENT ------------------------
df["Engagement_Score"] = (
    0.5 * (df["Previous_Purchases"] / 50)
    + 0.3 * (df["Orders_Per_Year"] / 52)
    + 0.2 * (df["Subscription_Status_bin"])
)

# ---------- D. SATISFACTION ----------------------------------
df["Satisfaction_Score"] = df["Review_Rating"] / 5
df["Satisfied_Flag"] = (df["Review_Rating"] >= 4.0).astype(int)

# ---------- E. GEOGRAPHY -------------------------------------
state_rev = df.groupby("Location")["Lifetime_Spend"].sum()
state_cnt = df.groupby("Location")["Customer_ID"].count()
nat_rpc = df["Lifetime_Spend"].sum() / df["Customer_ID"].nunique()
state_rpc = state_rev / state_cnt
df = df.merge(state_rpc.rename("State_Rev_Per_Customer"),
              left_on="Location", right_index=True)
df["Regional_Opportunity_Score"] = df["State_Rev_Per_Customer"] / nat_rpc

# ---------- F. CATEGORY -------------------------------------
PREMIUM = {"Outerwear"}
df["Premium_Category_Flag"] = df["Category"].isin(PREMIUM).astype(int)

# ---------- G. COMPOSITE VALUE SCORE -------------------------
def z(x): return (x - x.mean()) / x.std()

df["Value_Score"] = (
    0.40 * z(df["Lifetime_Spend"])
    + 0.25 * z(df["Engagement_Score"])
    + 0.20 * z(df["Satisfaction_Score"])
    - 0.15 * z(df["Discount_Dependency_Score"])
)
df["Value_Tier"] = pd.qcut(df["Value_Score"], 4,
    labels=["Low", "Mid", "High", "Top"])

df.to_csv("customers_features.csv", index=False)
print("Saved customers_features.csv, shape:", df.shape)
