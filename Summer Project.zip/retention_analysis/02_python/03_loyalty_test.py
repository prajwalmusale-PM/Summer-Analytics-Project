# ============================================================
# 03_loyalty_test.py — Loyalty Framework (two definitions)
# ============================================================
import pandas as pd
import numpy as np

d = pd.read_csv("customers_features.csv")

def z(x): return (x - x.mean()) / x.std()

# Definition A — Behavioural Loyalty (frequency-led)
d["Loyalty_A"] = (
    0.5 * d["Previous_Purchases"] / 50
    + 0.3 * d["Orders_Per_Year"] / 52
    + 0.2 * d["Subscription_Status_bin"]
)

# Definition B — Net Loyalty (satisfaction-adjusted, promo-penalised)
d["Loyalty_B"] = (
    0.40 * z(d["Previous_Purchases"])
    + 0.25 * z(d["Orders_Per_Year"])
    + 0.15 * d["Subscription_Status_bin"]
    + 0.20 * d["Satisfaction_Score"]
    - 0.20 * d["Discount_Applied_bin"]
)

print("Corr w/ Lifetime_Spend:")
print("  A:", d["Loyalty_A"].corr(d["Lifetime_Spend"]).round(4))
print("  B:", d["Loyalty_B"].corr(d["Lifetime_Spend"]).round(4))

print("Corr w/ Satisfaction:")
print("  A:", d["Loyalty_A"].corr(d["Satisfaction_Score"]).round(4))
print("  B:", d["Loyalty_B"].corr(d["Satisfaction_Score"]).round(4))

top_A = d.nlargest(int(len(d) * .2), "Loyalty_A")
top_B = d.nlargest(int(len(d) * .2), "Loyalty_B")
print("Promo rate in top-quintile:")
print(f"  A: {top_A['Discount_Applied_bin'].mean():.4f}")
print(f"  B: {top_B['Discount_Applied_bin'].mean():.4f}")

# Decision: Pick B if (i) corr_B >= corr_A with Lifetime_Spend AND
# (ii) top-quintile promo rate lower than A's
if (d["Loyalty_B"].corr(d["Lifetime_Spend"]) >= d["Loyalty_A"].corr(d["Lifetime_Spend"])
    and top_B["Discount_Applied_bin"].mean() < top_A["Discount_Applied_bin"].mean()):
    print("\nDECISION: Loyalty_B wins")
else:
    print("\nDECISION: Loyalty_A wins")

d.to_csv("customers_features.csv", index=False)
