# Executive Summary: Customer Retention Strategy

**Date:** June 2026 | **Dataset:** 3,900 customers, 18 attributes | **Analyst:** Retention Analytics Workstream

---

### Situation
A 3,900-customer D2C fashion brand operates a blanket discount and subscription programme without a defined view of customer value. We engineered a composite Value Score (z-blended across LTV, engagement, satisfaction; promo-penalised) and a satisfaction-adjusted Loyalty-B framework to answer: *which discount dollars are productive, and which are subsidising customers who would buy anyway?*

### Key Findings

**1. 43% of revenue is discount-funded — and much of it is unnecessary.**
$2.56M of $5.92M total revenue comes from customers who used a discount. Loyalty-B analysis of the top quintile reveals 487 "Genuine Loyal" customers (no discount, $2,489 LTV) versus 293 "Promo Loyal" (discount-used, $2,486 LTV, lower satisfaction). The promo-loyal segment buys from habit, not price — the discount is pure margin loss.

**2. Subscription guarantees a discount, but only 26.5% of top-tier customers subscribe.**
All 1,053 subscribers receive a discount. Yet the highest-value customers largely do not subscribe, suggesting subscription perks are misaligned with true value drivers. Subscription should shift from discount gateway to exclusive-access programme.

**3. Outerwear is the highest-LTV category ($2,597) but the lowest entry point (9.7%).**
Clothing dominates acquisition (43.9% of low-tenure customers), while Footwear shows highest LTV ($2,670). Outerwear retains well but needs a cross-sell bridge from Clothing entry buyers.

**4. Thirteen states are under-leveraged — above-average LTV, below-average customer count.**
Arizona (1.27x opportunity index), Alaska (1.23x), and Pennsylvania (1.23x) lead. Doubling customer count in these 13 states to the national median would yield ~$1.2M incremental revenue at constant AOV.

**5. The ideal customer is a 44-year-old subscriber buying Clothing weekly via Credit Card.**
Top-decile ICP: $3,646 avg LTV (2.4x baseline), 4.16 satisfaction, 35.6% promo rate. Target non-promo ICP subset for acquisition lookalikes on Meta Ads.

### Recommendations

| Priority | Action | Segment | Timeline | Owner | Expected Impact |
|----------|--------|---------|----------|-------|-----------------|
| **1** | Sunset discounts for High-Value Promo-Driven | 771 customers, Loyalty_B >= 0.30 | 90 days phased | Marketing + Finance | +$209K margin recovery |
| **2** | Stop discounts immediately for Low-Value Discount-Reliant | 533 customers, value_tier='Low' | Immediate | Marketing | +$62K margin recovery |
| **3** | Retarget subscription perks from discounts to exclusive Outerwear access | All subscribers | 60 days | Product + Marketing | Higher subscription rate in top tiers |
| **4** | Geo-expand in 13 over-indexed states via lookalike campaigns | Growth Opportunity segment | 90 days | Growth | +$1.2M incremental revenue |

### Expected Impact
- **Combined Year-1 margin uplift:** ~$271,090 from discount reduction alone
- **Revenue at risk:** <= 5 percentage points if monitored weekly with guardrails
- **Monitoring:** Repeat-purchase rate by segment (primary), revenue vs. 4-week trailing average, discount dependency score trend, customer satisfaction (n=50/week sample)
- **Guardrails:** Green (<=3pp rate change), Yellow (3-5pp: slow rollout), Red (>5pp: freeze; >10pp: revert)

### Bottom Line
*The brand is paying for loyalty it already has. A 90-day phased sunset targeting 1,304 customers (High-Value Promo-Driven + Low-Value Discount-Reliant) recovers ~$271K in annual margin with structured guardrails that keep revenue risk below 5pp. The ICP gives Marketing a precise lookalike target for profitable acquisition, and the 13 under-leveraged states provide a clear geo-expansion roadmap.*

---
*Methodology: Two loyalty definitions tested (Loyalty_A: frequency-led vs. Loyalty_B: satisfaction-adjusted, promo-penalised). Loyalty_B selected based on higher correlation with Lifetime_Spend (0.656 vs 0.578) and 50% lower promo rate in top quintile. Feature engineering, segmentation, and margin estimates documented in full playbook.*
